const RUN_PARABEAC = 'Run Parabeac';

/// Interpretation
const INTERPRETATION = 'Interpretation';
const HANDLE_CHILDREN = 'Handle Children';
const INTERMEDIATE_SERVICES = 'Intermediate Services';

/// Generation
const GENERATION = 'Generation';
const COMMAND_QUEUE = 'Command Queue';
const GEN_DRY_RUN = 'Gen AIT Dry Run';
const GEN_AIT = 'Gen AIT';

/// Misc
const PRE_GEN = 'Pre Gen Tasks';
const POST_GEN = 'Post Gen Tasks';
