/// Interface that defines that the node was injected by some semantic or understanding of the design files.
abstract class PBInjectedIntermediate {}
