class PBDLOverrideImage {
  static String PBDL_TYPE_NAME = 'image';
}
