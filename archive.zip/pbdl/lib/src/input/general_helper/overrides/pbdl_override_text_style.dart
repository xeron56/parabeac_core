class PBDLOverrideTextStyle {
  static String PBDL_TYPE_NAME = 'textStyle';
}
