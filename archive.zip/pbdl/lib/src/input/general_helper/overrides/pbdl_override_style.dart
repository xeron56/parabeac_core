class PBDLOverrideStyle {
  static String PBDL_TYPE_NAME = 'style';
}
