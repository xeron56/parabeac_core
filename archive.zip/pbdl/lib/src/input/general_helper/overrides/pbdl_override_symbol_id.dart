class PBDLOverrideSymbolID {
  static String PBDL_TYPE_NAME = 'symbolID';
}
