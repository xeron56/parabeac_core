class PBDLOverrideTextValue {
  static String PBDL_TYPE_NAME = 'stringValue';
}
