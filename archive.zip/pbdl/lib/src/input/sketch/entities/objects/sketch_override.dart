abstract class SketchOverride {
  String? overrideName;
}
