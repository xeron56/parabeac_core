// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'font_descriptor.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FontDescriptor _$FontDescriptorFromJson(Map<String, dynamic> json) {
  return FontDescriptor(
    rawAttributes: json['attributes'] as Map<String, dynamic>,
  );
}

Map<String, dynamic> _$FontDescriptorToJson(FontDescriptor instance) =>
    <String, dynamic>{
      'attributes': instance.rawAttributes,
    };
