// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'paragraph_style.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ParagraphStyle _$ParagraphStyleFromJson(Map<String, dynamic> json) {
  return ParagraphStyle(
    alignment: json['alignment'] as int?,
  );
}

Map<String, dynamic> _$ParagraphStyleToJson(ParagraphStyle instance) =>
    <String, dynamic>{
      'alignment': instance.alignment,
    };
