// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'global_style_holder.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GlobalStyleHolder _$GlobalStyleHolderFromJson(Map<String, dynamic> json) {
  return GlobalStyleHolder();
}

Map<String, dynamic> _$GlobalStyleHolderToJson(GlobalStyleHolder instance) =>
    <String, dynamic>{};
