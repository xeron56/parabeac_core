// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pbdl_color.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PBDLColor _$PBDLColorFromJson(Map<String, dynamic> json) {
  return PBDLColor(
    (json['a'] as num?)?.toDouble(),
    (json['r'] as num?)?.toDouble(),
    (json['g'] as num?)?.toDouble(),
    (json['b'] as num?)?.toDouble(),
  );
}

Map<String, dynamic> _$PBDLColorToJson(PBDLColor instance) => <String, dynamic>{
      'a': instance.a,
      'r': instance.r,
      'g': instance.g,
      'b': instance.b,
    };
