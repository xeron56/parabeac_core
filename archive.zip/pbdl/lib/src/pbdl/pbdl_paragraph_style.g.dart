// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pbdl_paragraph_style.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PBDLParagraphStyle _$PBDLParagraphStyleFromJson(Map<String, dynamic> json) {
  return PBDLParagraphStyle(
    alignment: json['alignment'] as int?,
  );
}

Map<String, dynamic> _$PBDLParagraphStyleToJson(PBDLParagraphStyle instance) =>
    <String, dynamic>{
      'alignment': instance.alignment,
    };
