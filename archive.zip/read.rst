figd_diKCE9I9wq8B27ncXFtVDlSznRiTAeDoBTW6j1n4
dart parabeac.dart  -f yhOJoOy8K3D6CufSFnIKuv -k figd_diKCE9I9wq8B27ncXFtVDlSznRiTAeDoBTW6j1n4 -o ./output_code
https://www.figma.com/file/NFpMwPburgAd1UuYEs53UH/aff_gen?type=design&node-id=0%3A1&mode=design&t=gpeMHxmcBzAuNPRT-1
sudo fvm dart --no-sound-null-safety parabeac.dart -f yhOJoOy8K3D6CufSFnIKuv -k figd_diKCE9I9wq8B27ncXFtVDlSznRiTAeDoBTW6j1n4 -o /workspaces/codeoutput/


fvm dart --debug --no-sound-null-safety parabeac.dart -f NFpMwPburgAd1UuYEs53UH -k figd_diKCE9I9wq8B27ncXFtVDlSznRiTAeDoBTW6j1n4 -o /workspaces/testapps/