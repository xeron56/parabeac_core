#!/bin/bash
fvm dart --no-sound-null-safety parabeac.dart -f NFpMwPburgAd1UuYEs53UH -k figd_diKCE9I9wq8B27ncXFtVDlSznRiTAeDoBTW6j1n4 -o /workspaces/testapps/